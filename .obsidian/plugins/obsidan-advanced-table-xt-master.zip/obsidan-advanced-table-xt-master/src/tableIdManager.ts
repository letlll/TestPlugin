// @ts-nocheck
// 上面的指令会禁用整个文件的类型检查

import { ObsidianSpreadsheet } from './main';
import { App, TFile, Notice } from 'obsidian';
import * as JSON5 from 'json5';

/**
 * 表格ID管理器 - 负责表格ID的生成、获取、解析和持久化
 */
export class TableIdManager {
    private plugin: ObsidianSpreadsheet;
    private static isProcessingTableId: boolean = false;
    private static isCreatingTableId: boolean = false;

    constructor(plugin: ObsidianSpreadsheet) {
        this.plugin = plugin;
        console.log('TableIdManager initialized');
    }

    /**
     * 获取表格的唯一标识符（ID）
     * @param table 表格HTML元素
     * @returns 表格ID或null
     */
    getTableIdentifier(table: HTMLElement): string | null {
        try {
            if (TableIdManager.isProcessingTableId) return null;
            TableIdManager.isProcessingTableId = true;

            // 策略1: 首先检查表格是否有data-table-id属性
            let tableId = table.getAttribute('data-table-id');
            if (tableId) {
                TableIdManager.isProcessingTableId = false;
                return tableId;
            }

            // 策略2: 检查HTML注释
            tableId = this.getTableIdFromComment(table);
            if (tableId) {
                // 将ID保存到表格属性中以便快速访问
                table.setAttribute('data-table-id', tableId);
                TableIdManager.isProcessingTableId = false;
                return tableId;
            }

            // 策略3: 检查Pandoc风格的表格标题
            const captionEl = table.querySelector('caption');
            if (captionEl) {
                const caption = captionEl.textContent || '';
                const pandocIdMatch = caption.match(/\{#(tbl:[\w-]+)\}/);
                if (pandocIdMatch && pandocIdMatch[1]) {
                    tableId = pandocIdMatch[1];
                    table.setAttribute('data-table-id', tableId);
                    TableIdManager.isProcessingTableId = false;
                    return tableId;
                }
            }

            // 策略4: 检查Obsidian块ID
            const lastRow = table.querySelector('tr:last-child');
            if (lastRow) {
                const lastCell = lastRow.querySelector('td:last-child, th:last-child');
                if (lastCell) {
                    const content = lastCell.textContent || '';
                    const blockIdMatch = content.match(/\^([\w-]+)$/);
                    if (blockIdMatch && blockIdMatch[1]) {
                        tableId = blockIdMatch[1];
                        table.setAttribute('data-table-id', tableId);
                        TableIdManager.isProcessingTableId = false;
                        return tableId;
                    }
                }
            }

            TableIdManager.isProcessingTableId = false;
            return null;
        } catch (error) {
            console.error('获取表格ID时出错:', error);
            TableIdManager.isProcessingTableId = false;
            return null;
        }
    }

    /**
     * 获取或创建表格ID
     * @param table 表格HTML元素
     * @returns 表格ID
     */
    getOrCreateTableId(table: HTMLElement): string {
        try {
            if (TableIdManager.isCreatingTableId) return '';
            TableIdManager.isCreatingTableId = true;

            // 首先尝试获取现有ID
            let tableId = this.getTableIdentifier(table);

            // 如果没有ID并且启用了表格ID，则创建新ID
            if (!tableId && this.plugin.settings.enableTableIds) {
                tableId = this.generateTableId();
                this.addTableIdComment(table, tableId);
                
                // 创建表格数据记录
                this.plugin.createTableData(table, tableId);
            }

            TableIdManager.isCreatingTableId = false;
            return tableId || '';
        } catch (error) {
            console.error('获取或创建表格ID时出错:', error);
            TableIdManager.isCreatingTableId = false;
            return '';
        }
    }

    /**
     * 从HTML注释中获取表格ID
     * @param table 表格HTML元素
     * @returns 表格ID或null
     */
    private getTableIdFromComment(table: HTMLElement): string | null {
        try {
            // 检查表格前面的注释节点
            let node = table.previousSibling;
            while (node) {
                // 只检查注释节点
                if (node.nodeType === Node.COMMENT_NODE) {
                    const commentText = node.textContent?.trim() || '';
                    
                    // 简化格式: table-id:xxx
                    const idMatch = commentText.match(/table-id:\s*([a-zA-Z0-9_\-:.]+)/i);
                    if (idMatch && idMatch[1]) {
                        return idMatch[1];
                    }
                }
                
                // 检查前一个兄弟节点
                node = node.previousSibling;
                
                // 限制只检查最近的几个节点，避免无限循环
                if (!node || node.nodeType === Node.ELEMENT_NODE) break;
            }
            
            return null;
        } catch (error) {
            console.error('从注释获取表格ID时出错:', error);
            return null;
        }
    }

    /**
     * 为表格添加ID注释
     * @param table 表格HTML元素
     * @param id 表格ID
     */
    private addTableIdComment(table: HTMLElement, id: string): void {
        try {
            // 先移除已有的注释（如果存在）
            const previousNode = table.previousSibling;
            if (previousNode && previousNode.nodeType === Node.COMMENT_NODE) {
                const comment = previousNode.nodeValue || '';
                if (comment.includes('table-id:')) {
                    previousNode.parentNode?.removeChild(previousNode);
                }
            }
            
            // 创建新的注释节点 - 使用简化格式
            const commentContent = `table-id: ${id}`;
            const comment = document.createComment(` ${commentContent} `);
            
            // 插入注释节点
            table.parentNode?.insertBefore(comment, table);
            
            // 设置表格属性
            table.setAttribute('data-table-id', id);
            
            console.log(`已为表格添加ID注释: ${id}`);
            new Notice(`已为表格添加ID: ${id}`);
        } catch (error) {
            console.error('添加表格ID注释时出错:', error);
        }
    }

    /**
     * 生成新的表格ID
     * @returns 生成的表格ID
     */
    generateTableId(): string {
        try {
            const prefix = this.plugin.settings.idPrefix || 'tbl';
            const timestamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
            const randomId = Math.random().toString(36).substring(2, 8);
            return `${prefix}-${timestamp}-${randomId}`;
        } catch (error) {
            console.error('生成表格ID时出错:', error);
            return `tbl-${Date.now()}`;
        }
    }

    /**
     * 计算字符串的简单哈希值
     * @param str 输入字符串
     * @returns 哈希值字符串
     */
    simpleHash(str: string): string {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // 转换为32bit整数
        }
        return Math.abs(hash).toString(16).substring(0, 8);
    }

    /**
     * 确保表格有ID，如果没有则创建一个
     * @param table 表格元素
     * @returns 表格ID
     */
    ensureTableHasId(table: HTMLElement): string {
        if (!table) return '';
        
        // 获取现有ID或创建新ID
        const tableId = this.getTableIdentifier(table) || this.generateTableId();
        
        // 如果没有ID，则添加永久ID
        if (!tableId) {
            // 生成一个新的永久ID
            const newId = this.generateTableId();
            
            // 添加表格ID注释
            this.addTableIdComment(table, newId);
            
            // 设置数据属性
            table.setAttribute('data-table-id', newId);
            
            // 创建表格数据记录
            this.plugin.createTableData(table, newId);
            
            return newId;
        }
        
        // 确保表格有数据属性
        if (!table.getAttribute('data-table-id')) {
            table.setAttribute('data-table-id', tableId);
        }
        
        return tableId;
    }
} 