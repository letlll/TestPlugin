// @ts-nocheck
// 上面的指令会禁用整个文件的类型检查

import { ObsidianSpreadsheet } from './main';
import { App, Notice, Modal, Setting } from 'obsidian';

/**
 * 确认对话框类 - 用于显示确认消息
 */
class ConfirmModal extends Modal {
    private result: boolean = false;
    private onClose: (result: boolean) => void;
    private message: string;

    constructor(app: App, message: string, onClose: (result: boolean) => void) {
        super(app);
        this.message = message;
        this.onClose = onClose;
    }

    onOpen() {
        const { contentEl } = this;
        
        contentEl.createEl('h2', { text: '确认操作' });
        contentEl.createEl('p', { text: this.message });
        
        const buttonContainer = contentEl.createDiv({ cls: 'modal-button-container' });
        
        buttonContainer.createEl('button', { text: '取消' })
            .addEventListener('click', () => {
                this.result = false;
                this.close();
            });
            
        buttonContainer.createEl('button', { text: '确认', cls: 'mod-cta' })
            .addEventListener('click', () => {
                this.result = true;
                this.close();
            });
    }

    onClose() {
        const { contentEl } = this;
        contentEl.empty();
        this.onClose(this.result);
    }
}

/**
 * Markdown表格检测器 - 负责检测、分析和处理Markdown表格
 */
export class MarkdownTableDetector {
    private plugin: ObsidianSpreadsheet;

    constructor(plugin: ObsidianSpreadsheet) {
        this.plugin = plugin;
        console.log('MarkdownTableDetector initialized');
    }
    
    /**
     * 显示确认对话框
     * @param message 确认消息
     * @returns 用户是否确认
     */
    async showConfirmDialog(message: string): Promise<boolean> {
        return new Promise((resolve) => {
            const modal = new ConfirmModal(this.plugin.app, message, (result) => {
                resolve(result);
            });
            modal.open();
        });
    }

    /**
     * 检查是否为HTML格式的表格（而非Markdown生成的表格）
     * @param table 表格HTML元素
     * @returns 是否为HTML格式的表格
     */
    isHtmlFormattedTable(table: HTMLElement): boolean {
        try {
            // 策略1: 检查是否有特定HTML表格属性
            if (table.hasAttribute('border') || 
                table.hasAttribute('cellpadding') || 
                table.hasAttribute('cellspacing') ||
                table.hasAttribute('width') ||
                table.hasAttribute('height') ||
                table.hasAttribute('bgcolor')) {
                return true;
            }
            
            // 策略2: 检查表格样式是否包含HTML特定样式
            const style = table.getAttribute('style');
            if (style && (
                style.includes('border-collapse') ||
                style.includes('text-align') ||
                style.includes('font-family') ||
                style.includes('background-color')
            )) {
                return true;
            }
            
            // 策略3: 检查表格单元格是否包含复杂HTML内容
            const cells = table.querySelectorAll('td, th');
            for (const cell of Array.from(cells).slice(0, 10)) { // 只检查前10个单元格
                const html = (cell as HTMLElement).innerHTML || '';
                // 如果单元格包含HTML标签（但排除Obsidian插入的简单格式标签）
                if (html.includes('<') && html.includes('>') && 
                    !html.match(/^<(em|strong|s|code|a|span)[^>]*>.*<\/(em|strong|s|code|a|span)>$/)) {
                    return true;
                }
            }
            
            // 策略4: 检查表格结构是否符合Markdown表格生成规则
            const rows = table.querySelectorAll('tr');
            if (rows.length > 1) {
                // Markdown表格的第二行通常是分隔行
                const secondRow = rows[1];
                const separatorCells = secondRow.querySelectorAll('td, th');
                
                // 分隔行的所有单元格内容通常只包含 ---- 或 :----: 等形式
                let isSeparatorRow = true;
                for (const cell of Array.from(separatorCells)) {
                    const text = cell.textContent || '';
                    // 如果不是分隔符格式，可能不是Markdown表格
                    if (!text.match(/^:?-+:?$/)) {
                        isSeparatorRow = false;
                        break;
                    }
                }
                
                // 如果不符合Markdown表格特征，可能是HTML表格
                if (!isSeparatorRow) {
                    return true;
                }
            }
            
            // 默认不是HTML格式的表格
            return false;
        } catch (error) {
            console.error('检测HTML表格时出错:', error);
            return false; // 错误时默认为否
        }
    }

    /**
     * 设置表格行列索引
     * @param table 表格HTML元素
     */
    setupTableIndices(table: HTMLElement): void {
        try {
            const rows = table.querySelectorAll('tr');
            
            for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                const row = rows[rowIndex];
                const cells = row.querySelectorAll('td, th');
                
                for (let colIndex = 0; colIndex < cells.length; colIndex++) {
                    const cell = cells[colIndex] as HTMLElement;
                    
                    // 设置数据属性存储行列索引
                    cell.dataset.rowIndex = rowIndex.toString();
                    cell.dataset.colIndex = colIndex.toString();
                    
                    // 设置row-index和col-index属性，确保与main.ts中使用的属性一致
                    cell.setAttribute('row-index', rowIndex.toString());
                    cell.setAttribute('col-index', colIndex.toString());
                    
                    // 为单元格添加类以便样式调整
                    cell.classList.add('advanced-table-cell');
                    
                    // 如果是表头单元格，添加特殊类
                    if (cell.tagName.toLowerCase() === 'th') {
                        cell.classList.add('advanced-table-header');
                    }
                    
                    // 为空单元格添加占位符
                    if (!cell.innerHTML.trim()) {
                        cell.innerHTML = '&nbsp;';
                    }
                }
            }
        } catch (error) {
            console.error('设置表格索引时出错:', error);
        }
    }

    /**
     * 检查单元格内容是否为合并标记
     * @param cell 单元格元素
     * @param marker 标记符号 ('^' 或 '<')
     * @returns 是否为指定的合并标记
     */
    isMergeMarker(cell: HTMLElement, marker: string): boolean {
        const content = cell.textContent?.trim() || '';
        return content === marker;
    }

    /**
     * 检查单元格是否非空且有有效内容
     * @param cell 单元格元素
     * @returns 是否有有效内容
     */
    hasMeaningfulContent(cell: HTMLElement): boolean {
        const content = cell.textContent?.trim() || '';
        // 检查是否为空或只有空格、合并标记
        return content !== '' && content !== '&nbsp;' && content !== '^' && content !== '<';
    }

    /**
     * 解析表格的合并标记
     * @param table 表格HTML元素
     */
    async parseMergeCellMarkers(table: HTMLElement): Promise<void> {
        if (!this.plugin.settings.enableCellMerging) return;
        
        try {
            const rows = table.querySelectorAll('tr');
            
            // 首先查找所有的合并标记
            const mergeUp: HTMLElement[] = [];
            const mergeLeft: HTMLElement[] = [];
            
            for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                const row = rows[rowIndex];
                const cells = row.querySelectorAll('td, th');
                
                for (let colIndex = 0; colIndex < cells.length; colIndex++) {
                    const cell = cells[colIndex] as HTMLElement;
                    const content = cell.textContent?.trim() || '';
                    
                    if (content === '^') {
                        mergeUp.push(cell);
                    } else if (content === '<') {
                        mergeLeft.push(cell);
                    }
                }
            }
            
            // 处理向上合并标记
            for (const cell of mergeUp) {
                const rowIndex = parseInt(cell.getAttribute('row-index') || cell.dataset.rowIndex || '0');
                const colIndex = parseInt(cell.getAttribute('col-index') || cell.dataset.colIndex || '0');
                
                if (rowIndex > 0) {
                    const targetRow = rows[rowIndex - 1];
                    if (targetRow) {
                        const targetCells = targetRow.querySelectorAll('td, th');
                        if (colIndex < targetCells.length) {
                            const targetCell = targetCells[colIndex] as HTMLElement;
                            
                            // 检查目标单元格是否有实际内容
                            if (this.hasMeaningfulContent(targetCell)) {
                                // 确认是否覆盖非空单元格
                                if (this.plugin.settings.confirmMergeNonEmpty && this.hasMeaningfulContent(cell)) {
                                    const confirmMerge = await this.showConfirmDialog(
                                        `单元格包含内容"${cell.textContent?.trim()}"，确定要合并并覆盖此内容吗？`
                                    );
                                    
                                    if (!confirmMerge) {
                                        console.log('用户取消了单元格合并');
                                        continue;
                                    }
                                }
                                
                                // 获取目标单元格当前的rowspan
                                let rowSpan = parseInt(targetCell.getAttribute('rowspan') || '1');
                                rowSpan++;
                                
                                // 设置新的rowspan
                                targetCell.setAttribute('rowspan', rowSpan.toString());
                                targetCell.rowSpan = rowSpan;
                                
                                // 添加合并样式类
                                targetCell.classList.add('obs-merged-cell');
                                
                                // 隐藏当前单元格
                                cell.style.display = 'none';
                            } else {
                                console.warn('向上合并失败: 目标单元格没有有效内容', targetCell);
                            }
                        }
                    }
                }
            }
            
            // 处理向左合并标记
            for (const cell of mergeLeft) {
                const rowIndex = parseInt(cell.getAttribute('row-index') || cell.dataset.rowIndex || '0');
                const colIndex = parseInt(cell.getAttribute('col-index') || cell.dataset.colIndex || '0');
                
                if (colIndex > 0) {
                    const targetCell = rows[rowIndex]?.querySelectorAll('td, th')[colIndex - 1] as HTMLElement;
                    if (targetCell) {
                        // 检查目标单元格是否有实际内容
                        if (this.hasMeaningfulContent(targetCell)) {
                            // 确认是否覆盖非空单元格
                            if (this.plugin.settings.confirmMergeNonEmpty && this.hasMeaningfulContent(cell)) {
                                const confirmMerge = await this.showConfirmDialog(
                                    `单元格包含内容"${cell.textContent?.trim()}"，确定要合并并覆盖此内容吗？`
                                );
                                
                                if (!confirmMerge) {
                                    console.log('用户取消了单元格合并');
                                    continue;
                                }
                            }
                            
                            // 获取目标单元格当前的colspan
                            let colSpan = parseInt(targetCell.getAttribute('colspan') || '1');
                            colSpan++;
                            
                            // 设置新的colspan
                            targetCell.setAttribute('colspan', colSpan.toString());
                            targetCell.colSpan = colSpan;
                            
                            // 添加合并样式类
                            targetCell.classList.add('obs-merged-cell');
                            
                            // 隐藏当前单元格
                            cell.style.display = 'none';
                        } else {
                            console.warn('向左合并失败: 目标单元格没有有效内容', targetCell);
                        }
                    }
                }
            }
            
            // 如果启用了自动居中，对合并的单元格应用居中样式
            if (this.plugin.settings.autoCenterMergedCells) {
                const mergedCells = table.querySelectorAll('[rowspan], [colspan]');
                mergedCells.forEach(cell => {
                    const htmlCell = cell as HTMLElement;
                    if (parseInt(htmlCell.getAttribute('rowspan') || '1') > 1 || 
                        parseInt(htmlCell.getAttribute('colspan') || '1') > 1) {
                        htmlCell.style.textAlign = 'center';
                        htmlCell.style.verticalAlign = 'middle';
                        htmlCell.classList.add('obs-merged-cell');
                    }
                });
            }
        } catch (error) {
            console.error('解析单元格合并标记时出错:', error);
        }
    }

    /**
     * 应用表格合并标记到Markdown
     * @param table 表格HTML元素
     */
    applyMergeCellsMarkers(table: HTMLElement): void {
        try {
            // 检查表格是否已经处理过
            if (table.dataset.tableMergeProcessed === 'true') {
                return;
            }
            
            const rows = table.querySelectorAll('tr');
            
            // 检查每个合并的单元格
            for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                const row = rows[rowIndex];
                const cells = row.querySelectorAll('td, th');
                
                for (let colIndex = 0; colIndex < cells.length; colIndex++) {
                    const cell = cells[colIndex] as HTMLElement;
                    const cellContent = cell.textContent?.trim() || '';
                    
                    // 检查是否是合并标记
                    const isLeftMergeMarker = cellContent === '<' || cellContent === '\\<' || 
                                             cellContent === ' < ' || cellContent === ' \\< ';
                    const isUpMergeMarker = cellContent === '^' || cellContent === '\\^' || 
                                           cellContent === ' ^ ' || cellContent === ' \\^ ';
                    
                    // 处理向左合并标记
                    if (isLeftMergeMarker && colIndex > 0) {
                        const leftCell = cells[colIndex - 1] as HTMLTableCellElement;
                        leftCell.colSpan = (leftCell.colSpan || 1) + 1;
                        cell.style.display = 'none';
                        
                        // 如果启用了自动居中
                        if (this.plugin.settings.autoCenterMergedCells) {
                            leftCell.style.textAlign = 'center';
                            leftCell.style.verticalAlign = 'middle';
                        }
                        
                        // 添加合并样式类
                        leftCell.classList.add('obs-merged-cell');
                    }
                    
                    // 处理向上合并标记
                    else if (isUpMergeMarker && rowIndex > 0) {
                        const aboveRow = rows[rowIndex - 1];
                        const aboveCells = aboveRow.querySelectorAll('td, th');
                        
                        if (colIndex < aboveCells.length) {
                            const aboveCell = aboveCells[colIndex] as HTMLTableCellElement;
                            aboveCell.rowSpan = (aboveCell.rowSpan || 1) + 1;
                            cell.style.display = 'none';
                            
                            // 如果启用了自动居中
                            if (this.plugin.settings.autoCenterMergedCells) {
                                aboveCell.style.textAlign = 'center';
                                aboveCell.style.verticalAlign = 'middle';
                            }
                            
                            // 添加合并样式类
                            aboveCell.classList.add('obs-merged-cell');
                        }
                    }
                    
                    // 获取rowspan和colspan
                    const rowSpan = parseInt(cell.getAttribute('rowspan') || '1');
                    const colSpan = parseInt(cell.getAttribute('colspan') || '1');
                    
                    // 如果有合并，为下方的单元格添加向上合并标记(^)
                    if (rowSpan > 1) {
                        for (let i = 1; i < rowSpan; i++) {
                            if (rowIndex + i < rows.length) {
                                const targetRow = rows[rowIndex + i];
                                const targetCells = targetRow.querySelectorAll('td, th');
                                if (colIndex < targetCells.length) {
                                    const targetCell = targetCells[colIndex] as HTMLElement;
                                    targetCell.textContent = '^';
                                    targetCell.classList.add('merge-marker');
                                }
                            }
                        }
                    }
                    
                    // 如果有合并，为右侧的单元格添加向左合并标记(<)
                    if (colSpan > 1) {
                        for (let i = 1; i < colSpan; i++) {
                            if (colIndex + i < cells.length) {
                                const targetCell = cells[colIndex + i] as HTMLElement;
                                targetCell.textContent = '<';
                                targetCell.classList.add('merge-marker');
                            }
                        }
                    }
                }
            }
            
            // 标记表格为已处理
            table.dataset.tableMergeProcessed = 'true';
            
        } catch (error) {
            console.error('应用合并单元格标记时出错:', error);
        }
    }

    /**
     * 处理多选单元格合并
     * @param table 表格元素
     * @param selectedCells 选中的单元格数组
     * @returns 是否成功合并
     */
    async mergeSelectedCells(table: HTMLElement, selectedCells: HTMLElement[]): Promise<boolean> {
        if (!selectedCells || selectedCells.length < 2) {
            new Notice('请选择至少2个单元格进行合并');
            return false;
        }

        try {
            // 确定选中区域的边界
            let minRow = Number.MAX_SAFE_INTEGER;
            let maxRow = 0;
            let minCol = Number.MAX_SAFE_INTEGER;
            let maxCol = 0;

            // 检查所有选中单元格并记录边界
            for (const cell of selectedCells) {
                const rowIndex = parseInt(cell.getAttribute('row-index') || cell.dataset.rowIndex || '0');
                const colIndex = parseInt(cell.getAttribute('col-index') || cell.dataset.colIndex || '0');
                
                minRow = Math.min(minRow, rowIndex);
                maxRow = Math.max(maxRow, rowIndex);
                minCol = Math.min(minCol, colIndex);
                maxCol = Math.max(maxCol, colIndex);
            }

            // 验证是否形成完整矩形
            const expectedCellCount = (maxRow - minRow + 1) * (maxCol - minCol + 1);
            if (expectedCellCount !== selectedCells.length) {
                new Notice('只能合并形成完整矩形的单元格');
                return false;
            }

            // 确定左上角单元格作为主单元格
            const mainCell = table.querySelector(`[row-index="${minRow}"][col-index="${minCol}"]`) as HTMLElement;
            if (!mainCell) {
                new Notice('无法找到主单元格');
                return false;
            }
            
            // 检查是否有非空单元格需要确认
            if (this.plugin.settings.confirmMergeNonEmpty) {
                const nonEmptyCells = selectedCells.filter(cell => {
                    if (cell === mainCell) return false; // 忽略主单元格
                    return this.hasMeaningfulContent(cell);
                });
                
                if (nonEmptyCells.length > 0) {
                    // 获取非空单元格的内容列表
                    const cellContents = nonEmptyCells.map(cell => 
                        `${cell.textContent?.trim() || '(空)'}`
                    ).join(', ');
                    
                    // 创建并显示确认对话框
                    const confirmMerge = await this.showConfirmDialog(
                        `单元格包含内容"${cellContents}"，确定要合并并覆盖这些内容吗？`
                    );
                    
                    if (!confirmMerge) {
                        new Notice('已取消合并操作');
                        return false;
                    }
                }
            }

            // 设置合并属性
            const rowSpanValue = maxRow - minRow + 1;
            const colSpanValue = maxCol - minCol + 1;
            
            mainCell.setAttribute('rowspan', rowSpanValue.toString());
            mainCell.setAttribute('colspan', colSpanValue.toString());
            mainCell.rowSpan = rowSpanValue;
            mainCell.colSpan = colSpanValue;
            mainCell.classList.add('obs-merged-cell');

            // 隐藏其他单元格
            for (const cell of selectedCells) {
                if (cell !== mainCell) {
                    cell.style.display = 'none';
                }
            }

            // 应用合并标记到Markdown
            this.applyMergeCellsMarkersForArea(table, minRow, minCol, maxRow, maxCol);

            // 自动居中处理
            if (this.plugin.settings.autoCenterMergedCells) {
                mainCell.style.textAlign = 'center';
                mainCell.style.verticalAlign = 'middle';
            }
            
            // 确保表格有ID
            if (this.plugin.tableIdManager) {
            this.plugin.tableIdManager.ensureTableHasId(table);
            }

            new Notice('已成功合并选中的单元格');
            return true;
        } catch (error) {
            console.error('合并选中单元格时出错:', error);
            new Notice('合并单元格时出错，请查看控制台');
            return false;
        }
    }

    /**
     * 为特定区域应用合并标记
     * @param table 表格元素
     * @param startRow 起始行
     * @param startCol 起始列
     * @param endRow 结束行
     * @param endCol 结束列
     */
    private applyMergeCellsMarkersForArea(table: HTMLElement, startRow: number, startCol: number, endRow: number, endCol: number): void {
        try {
            const rows = table.querySelectorAll('tr');
            
            // 对区域内除了左上角单元格外的所有单元格应用合并标记
            for (let rowIndex = startRow; rowIndex <= endRow; rowIndex++) {
                if (rowIndex < rows.length) {
                    const row = rows[rowIndex];
                    const cells = row.querySelectorAll('td, th');
                    
                    for (let colIndex = startCol; colIndex <= endCol; colIndex++) {
                        if (colIndex < cells.length && !(rowIndex === startRow && colIndex === startCol)) {
                            const cell = cells[colIndex] as HTMLElement;
                            
                            // 第一列的单元格使用向上合并标记(^)
                            if (colIndex === startCol) {
                                cell.textContent = '^';
                                cell.classList.add('merge-marker');
                            } 
                            // 第一行的单元格使用向左合并标记(<)
                            else if (rowIndex === startRow) {
                                cell.textContent = '<';
                                cell.classList.add('merge-marker');
                            }
                            // 其他单元格随机使用一种标记，保证不会看到
                            else {
                                cell.textContent = (Math.random() > 0.5) ? '^' : '<';
                                cell.classList.add('merge-marker', 'hidden-marker');
                            }
                        }
                    }
                }
            }
        } catch (error) {
            console.error('应用区域合并标记时出错:', error);
        }
    }
} 